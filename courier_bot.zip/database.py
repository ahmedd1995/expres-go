
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()

class Order(Base):
    __tablename__ = 'orders'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    phone = Column(String)
    from_address = Column(String)
    to_address = Column(String)
    status = Column(String, default="Принят")

engine = create_engine('sqlite:///orders.db')
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
